"""Independent local pet room."""
